-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 29 juil. 2024 à 10:08
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `laboratoire`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

DROP TABLE IF EXISTS `administrateur`;
CREATE TABLE IF NOT EXISTS `administrateur` (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `effectuer`
--

DROP TABLE IF EXISTS `effectuer`;
CREATE TABLE IF NOT EXISTS `effectuer` (
  `numero` int NOT NULL AUTO_INCREMENT,
  `id_patient` int DEFAULT NULL,
  `id_laborantin` int DEFAULT NULL,
  `id_examen` int DEFAULT NULL,
  `deleted` int DEFAULT '0',
  `date_examen` datetime DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `id_patient` (`id_patient`),
  KEY `id_laborantin` (`id_laborantin`),
  KEY `id_examen` (`id_examen`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `effectuer`
--

INSERT INTO `effectuer` (`numero`, `id_patient`, `id_laborantin`, `id_examen`, `deleted`, `date_examen`) VALUES
(44, 18, 1, 40, 0, '2024-07-29 09:35:44'),
(45, 18, 1, 41, 0, '2024-07-29 09:35:44'),
(46, 18, 1, 43, 0, '2024-07-29 09:35:44'),
(47, 18, 1, 42, 0, '2024-07-29 09:35:44'),
(48, 18, 1, 44, 0, '2024-07-29 09:35:44'),
(49, 18, 1, 46, 0, '2024-07-29 09:35:44'),
(50, 18, 1, 40, 0, '2024-07-29 09:36:19'),
(51, 18, 1, 43, 0, '2024-07-29 09:36:19'),
(52, 18, 1, 49, 0, '2024-07-29 09:36:19'),
(53, 18, 1, 40, 0, '2024-07-29 09:40:38'),
(54, 18, 1, 40, 0, '2024-07-29 09:41:22'),
(55, 32, 1, 40, 0, '2024-07-29 09:41:42');

-- --------------------------------------------------------

--
-- Structure de la table `examen`
--

DROP TABLE IF EXISTS `examen`;
CREATE TABLE IF NOT EXISTS `examen` (
  `id_examen` int NOT NULL AUTO_INCREMENT,
  `id_famille` int DEFAULT NULL,
  `nom_examen` varchar(255) DEFAULT NULL,
  `resultat` varchar(255) DEFAULT NULL,
  `norme` varchar(255) DEFAULT NULL,
  `unite` varchar(255) DEFAULT NULL,
  `conclusion` varchar(255) DEFAULT NULL,
  `deleted` int DEFAULT '0',
  `montant` int DEFAULT NULL,
  PRIMARY KEY (`id_examen`),
  KEY `tb_examen_fkey` (`id_famille`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `examen`
--

INSERT INTO `examen` (`id_examen`, `id_famille`, `nom_examen`, `resultat`, `norme`, `unite`, `conclusion`, `deleted`, `montant`) VALUES
(40, 101, 'CRP', '', '0 – 10', 'mg/l', '', 0, 0),
(41, 102, 'CRP', '', '0-10', 'mg/l', '', 0, 0),
(42, 102, 'RUBEOLE', '', '0,8', '/', '', 0, 0),
(43, 102, 'CHLAMYDIA Ag', '', '<0,8', '', '', 0, 0),
(44, 102, 'HEMOGLOBINE GLYQUEE', '', '', '', '', 0, 0),
(45, 101, 'UREE', '', '10 - 50', 'mg/li', '', 0, 0),
(46, 101, 'CREATININE', '', 'H : 0,6 – 1,4 ', 'mg/dl', '', 0, 0),
(47, 103, 'CREATININE', '', 'H : 0,6 – 1,4 ', '', '', 0, 0),
(48, 101, 'la\'dsfsdfsdf', '', '', '', '', 0, 0),
(49, 104, 'tyu', '', 't456', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `famille_examen`
--

DROP TABLE IF EXISTS `famille_examen`;
CREATE TABLE IF NOT EXISTS `famille_examen` (
  `id_famille` int NOT NULL AUTO_INCREMENT,
  `nom_famille` varchar(255) DEFAULT NULL,
  `deleted` int DEFAULT '0',
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_famille`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `famille_examen`
--

INSERT INTO `famille_examen` (`id_famille`, `nom_famille`, `deleted`, `description`) VALUES
(101, 'predmvk', 0, 'spécimen'),
(102, 'TECHNIQUE IMMUNOFLUORESCENCE', 0, 'Spécimen : sang total/sérum/plasma/fèces/ pendocervicale'),
(103, 'BIOCHIMIE CLINIQUE  ', 0, 'Spécimen : sérum/plasma'),
(104, 'IMMUNO-SEROLOGIE CLINIQUE', 0, 'Spécimen : sérum/plasma'),
(105, 'HEMATOLOGIE CLINIQUE', 0, 'Spécimen : sang total'),
(106, 'PARASITOLOGIE/BACTERIOLOGIE CLINIQUE', 0, 'Spécimen : sang total/urines/pcv/pu/pvbiopsiecutanée/lcr/crachats/selles'),
(107, 'l\'boncxvc ', 0, 'dfvbdf'),
(108, 'vhghjg;', 0, 'nbvbnvgh'),
(109, 'nbvkvyt', 0, 'fdjfgdgf\n'),
(110, 'nbh', 0, 'mjnljk.'),
(111, 'l\'sdfs', 0, 'dsfsdf'),
(112, 'l\'animal', 0, 'fsdmnbsd'),
(113, 'l;\'adsafsdf l\'afdasfsdf', 0, 'sfsdf'),
(114, 'l\'adfvfdav', 0, 'l\'adfv');

-- --------------------------------------------------------

--
-- Structure de la table `laborentain`
--

DROP TABLE IF EXISTS `laborentain`;
CREATE TABLE IF NOT EXISTS `laborentain` (
  `id_laborantin` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `id_admin` int DEFAULT NULL,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`id_laborantin`),
  KEY `TB_LABO_FKEY` (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `laborentain`
--

INSERT INTO `laborentain` (`id_laborantin`, `nom`, `prenom`, `email`, `login`, `mot_de_passe`, `photo`, `id_admin`, `deleted`) VALUES
(1, 'Tchamou', NULL, NULL, NULL, '1234', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `id_patient` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `services` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `sexe` varchar(255) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `prescripteur` varchar(255) DEFAULT NULL,
  `deleted` int DEFAULT '0',
  `date_reception` datetime DEFAULT NULL,
  `date_prelevement` datetime DEFAULT NULL,
  `date_examen` datetime DEFAULT NULL,
  PRIMARY KEY (`id_patient`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`id_patient`, `nom`, `prenom`, `profession`, `services`, `age`, `sexe`, `adresse`, `prescripteur`, `deleted`, `date_reception`, `date_prelevement`, `date_examen`) VALUES
(18, 'Tchamou', 'Brice', 'developpeur', 'biologie', '14', 'masculin', 'bafoussam', 'Dr jago', 0, NULL, NULL, NULL),
(19, 'Lopez', 'Youmbo', 'Developpeur', 'Laboratoire', '20', 'masculin', 'Mbouda', 'Dr Fok0', 0, NULL, NULL, NULL),
(20, 'Fokou', 'Kevin', 'reseauticien', 'laboratoire', '23', 'masculin', 'sdcsd', 'Dr sscsd', 0, NULL, NULL, NULL),
(21, 'Fokou', 'Kevin', 'reseauticien', 'laboratoire', '23', 'masculin', 'sdcsd', 'Dr sscsd', 0, NULL, NULL, NULL),
(22, 'Kengne', 'joel', 'expert comptable', 'laboratoire', '22', 'masculin', 'Douala', 'Dr Joshua', 0, NULL, NULL, NULL),
(23, 'dsa', 'sdd', 'asd', 'sdc', '12', 'masculin', 'asd', 'wqdqw', 0, NULL, NULL, NULL),
(24, 'Mbopda', 'Andre', 'Eleveur', 'Laboratoire', '23', 'masculin', '699324312', 'Dr fsdfs', 0, NULL, NULL, NULL),
(25, '', '', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(26, '', 'dvdfd\'sdfsd', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(27, '', '', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(28, 'mfnbvdlf.', '', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(29, 'dkjfghkjdfh', '', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(30, 'l\'amin yamal', '', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(31, 'léà\'kkkjkl', '', '', '', '', 'masculin', '', '', 0, NULL, NULL, NULL),
(32, 't\'chams', '', '', '', '', 'masculin', '', '', 0, '2024-07-29 07:50:00', '2024-07-29 07:50:00', NULL),
(33, 't\'chams', '', '', '', '', 'masculin', '', '', 0, '2024-07-29 07:50:00', '2024-07-29 07:50:00', NULL);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `examen`
--
ALTER TABLE `examen`
  ADD CONSTRAINT `tb_examen_fkey` FOREIGN KEY (`id_famille`) REFERENCES `famille_examen` (`id_famille`);

--
-- Contraintes pour la table `laborentain`
--
ALTER TABLE `laborentain`
  ADD CONSTRAINT `TB_LABO_FKEY` FOREIGN KEY (`id_admin`) REFERENCES `administrateur` (`id_admin`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
