---
title: Upgrading
taxonomy:
    category: docs
---

# Upgrading Select2
